<?php
define('SERVERNAME', '127.0.0.1'); // имя сервера
define('DBNAME', 'myDB0B1'); //имя базы данных
define('USERNAME', 'root'); //имя пользователя базы данных
define('PASSWORD', ''); // пароль доступа к базе данных